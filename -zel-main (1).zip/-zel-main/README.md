# -zel
özel
